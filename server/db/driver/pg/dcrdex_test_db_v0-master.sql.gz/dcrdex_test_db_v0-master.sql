--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btc_ltc; Type: SCHEMA; Schema: -; Owner: dcrdex
--

CREATE SCHEMA btc_ltc;


ALTER SCHEMA btc_ltc OWNER TO dcrdex;

--
-- Name: dcr_btc; Type: SCHEMA; Schema: -; Owner: dcrdex
--

CREATE SCHEMA dcr_btc;


ALTER SCHEMA dcr_btc OWNER TO dcrdex;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cancels_active; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.cancels_active (
    oid bytea NOT NULL,
    account_id bytea,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    target_order bytea,
    status smallint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea
);


ALTER TABLE btc_ltc.cancels_active OWNER TO dcrdex;

--
-- Name: cancels_archived; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.cancels_archived (
    oid bytea NOT NULL,
    account_id bytea,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    target_order bytea,
    status smallint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea
);


ALTER TABLE btc_ltc.cancels_archived OWNER TO dcrdex;

--
-- Name: epoch_reports; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.epoch_reports (
    epoch_end bigint NOT NULL,
    epoch_dur integer,
    match_volume bigint,
    quote_volume bigint,
    book_buys bigint,
    book_buys_5 bigint,
    book_buys_25 bigint,
    book_sells bigint,
    book_sells_5 bigint,
    book_sells_25 bigint,
    high_rate bigint,
    low_rate bigint,
    start_rate bigint,
    end_rate bigint
);


ALTER TABLE btc_ltc.epoch_reports OWNER TO dcrdex;

--
-- Name: epochs; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.epochs (
    epoch_idx bigint NOT NULL,
    epoch_dur integer NOT NULL,
    match_time bigint,
    csum bytea,
    seed bytea,
    revealed bytea[],
    missed bytea[]
);


ALTER TABLE btc_ltc.epochs OWNER TO dcrdex;

--
-- Name: matches; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.matches (
    matchid bytea NOT NULL,
    active boolean DEFAULT true,
    takersell boolean,
    takerorder bytea,
    takeraccount bytea,
    takeraddress text,
    makerorder bytea,
    makeraccount bytea,
    makeraddress text,
    epochidx bigint,
    epochdur bigint,
    quantity bigint,
    rate bigint,
    baserate bigint,
    quoterate bigint,
    status smallint,
    forgiven boolean,
    sigmatchackmaker bytea,
    sigmatchacktaker bytea,
    acontractcoinid bytea,
    acontract bytea,
    acontracttime bigint,
    bsigackofacontract bytea,
    bcontractcoinid bytea,
    bcontract bytea,
    bcontracttime bigint,
    asigackofbcontract bytea,
    aredeemcoinid bytea,
    aredeemsecret bytea,
    aredeemtime bigint,
    bsigackofaredeem bytea,
    bredeemcoinid bytea,
    bredeemtime bigint
);


ALTER TABLE btc_ltc.matches OWNER TO dcrdex;

--
-- Name: orders_active; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.orders_active (
    oid bytea NOT NULL,
    type smallint,
    sell boolean,
    account_id bytea,
    address text,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    coins bytea,
    quantity bigint,
    rate bigint,
    force smallint,
    status smallint,
    filled bigint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea,
    complete_time bigint
);


ALTER TABLE btc_ltc.orders_active OWNER TO dcrdex;

--
-- Name: orders_archived; Type: TABLE; Schema: btc_ltc; Owner: dcrdex
--

CREATE TABLE btc_ltc.orders_archived (
    oid bytea NOT NULL,
    type smallint,
    sell boolean,
    account_id bytea,
    address text,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    coins bytea,
    quantity bigint,
    rate bigint,
    force smallint,
    status smallint,
    filled bigint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea,
    complete_time bigint
);


ALTER TABLE btc_ltc.orders_archived OWNER TO dcrdex;

--
-- Name: cancels_active; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.cancels_active (
    oid bytea NOT NULL,
    account_id bytea,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    target_order bytea,
    status smallint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea
);


ALTER TABLE dcr_btc.cancels_active OWNER TO dcrdex;

--
-- Name: cancels_archived; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.cancels_archived (
    oid bytea NOT NULL,
    account_id bytea,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    target_order bytea,
    status smallint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea
);


ALTER TABLE dcr_btc.cancels_archived OWNER TO dcrdex;

--
-- Name: epoch_reports; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.epoch_reports (
    epoch_end bigint NOT NULL,
    epoch_dur integer,
    match_volume bigint,
    quote_volume bigint,
    book_buys bigint,
    book_buys_5 bigint,
    book_buys_25 bigint,
    book_sells bigint,
    book_sells_5 bigint,
    book_sells_25 bigint,
    high_rate bigint,
    low_rate bigint,
    start_rate bigint,
    end_rate bigint
);


ALTER TABLE dcr_btc.epoch_reports OWNER TO dcrdex;

--
-- Name: epochs; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.epochs (
    epoch_idx bigint NOT NULL,
    epoch_dur integer NOT NULL,
    match_time bigint,
    csum bytea,
    seed bytea,
    revealed bytea[],
    missed bytea[]
);


ALTER TABLE dcr_btc.epochs OWNER TO dcrdex;

--
-- Name: matches; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.matches (
    matchid bytea NOT NULL,
    active boolean DEFAULT true,
    takersell boolean,
    takerorder bytea,
    takeraccount bytea,
    takeraddress text,
    makerorder bytea,
    makeraccount bytea,
    makeraddress text,
    epochidx bigint,
    epochdur bigint,
    quantity bigint,
    rate bigint,
    baserate bigint,
    quoterate bigint,
    status smallint,
    forgiven boolean,
    sigmatchackmaker bytea,
    sigmatchacktaker bytea,
    acontractcoinid bytea,
    acontract bytea,
    acontracttime bigint,
    bsigackofacontract bytea,
    bcontractcoinid bytea,
    bcontract bytea,
    bcontracttime bigint,
    asigackofbcontract bytea,
    aredeemcoinid bytea,
    aredeemsecret bytea,
    aredeemtime bigint,
    bsigackofaredeem bytea,
    bredeemcoinid bytea,
    bredeemtime bigint
);


ALTER TABLE dcr_btc.matches OWNER TO dcrdex;

--
-- Name: orders_active; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.orders_active (
    oid bytea NOT NULL,
    type smallint,
    sell boolean,
    account_id bytea,
    address text,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    coins bytea,
    quantity bigint,
    rate bigint,
    force smallint,
    status smallint,
    filled bigint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea,
    complete_time bigint
);


ALTER TABLE dcr_btc.orders_active OWNER TO dcrdex;

--
-- Name: orders_archived; Type: TABLE; Schema: dcr_btc; Owner: dcrdex
--

CREATE TABLE dcr_btc.orders_archived (
    oid bytea NOT NULL,
    type smallint,
    sell boolean,
    account_id bytea,
    address text,
    client_time timestamp with time zone,
    server_time timestamp with time zone,
    commit bytea,
    coins bytea,
    quantity bigint,
    rate bigint,
    force smallint,
    status smallint,
    filled bigint,
    epoch_idx bigint,
    epoch_dur integer,
    preimage bytea,
    complete_time bigint
);


ALTER TABLE dcr_btc.orders_archived OWNER TO dcrdex;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: dcrdex
--

CREATE TABLE public.accounts (
    account_id bytea NOT NULL,
    pubkey bytea,
    fee_address text,
    fee_coin bytea,
    broken_rule smallint DEFAULT 0
);


ALTER TABLE public.accounts OWNER TO dcrdex;

--
-- Name: fee_keys; Type: TABLE; Schema: public; Owner: dcrdex
--

CREATE TABLE public.fee_keys (
    key_hash bytea NOT NULL,
    child bigint DEFAULT 0
);


ALTER TABLE public.fee_keys OWNER TO dcrdex;

--
-- Name: markets; Type: TABLE; Schema: public; Owner: dcrdex
--

CREATE TABLE public.markets (
    name text NOT NULL,
    base smallint,
    quote smallint,
    lot_size bigint
);


ALTER TABLE public.markets OWNER TO dcrdex;

--
-- Data for Name: cancels_active; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.cancels_active (oid, account_id, client_time, server_time, commit, target_order, status, epoch_idx, epoch_dur, preimage) FROM stdin;
\.


--
-- Data for Name: cancels_archived; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.cancels_archived (oid, account_id, client_time, server_time, commit, target_order, status, epoch_idx, epoch_dur, preimage) FROM stdin;
\.


--
-- Data for Name: epoch_reports; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.epoch_reports (epoch_end, epoch_dur, match_volume, quote_volume, book_buys, book_buys_5, book_buys_25, book_sells, book_sells_5, book_sells_25, high_rate, low_rate, start_rate, end_rate) FROM stdin;
\.


--
-- Data for Name: epochs; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.epochs (epoch_idx, epoch_dur, match_time, csum, seed, revealed, missed) FROM stdin;
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.matches (matchid, active, takersell, takerorder, takeraccount, takeraddress, makerorder, makeraccount, makeraddress, epochidx, epochdur, quantity, rate, baserate, quoterate, status, forgiven, sigmatchackmaker, sigmatchacktaker, acontractcoinid, acontract, acontracttime, bsigackofacontract, bcontractcoinid, bcontract, bcontracttime, asigackofbcontract, aredeemcoinid, aredeemsecret, aredeemtime, bsigackofaredeem, bredeemcoinid, bredeemtime) FROM stdin;
\.


--
-- Data for Name: orders_active; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.orders_active (oid, type, sell, account_id, address, client_time, server_time, commit, coins, quantity, rate, force, status, filled, epoch_idx, epoch_dur, preimage, complete_time) FROM stdin;
\.


--
-- Data for Name: orders_archived; Type: TABLE DATA; Schema: btc_ltc; Owner: dcrdex
--

COPY btc_ltc.orders_archived (oid, type, sell, account_id, address, client_time, server_time, commit, coins, quantity, rate, force, status, filled, epoch_idx, epoch_dur, preimage, complete_time) FROM stdin;
\.


--
-- Data for Name: cancels_active; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.cancels_active (oid, account_id, client_time, server_time, commit, target_order, status, epoch_idx, epoch_dur, preimage) FROM stdin;
\.


--
-- Data for Name: cancels_archived; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.cancels_archived (oid, account_id, client_time, server_time, commit, target_order, status, epoch_idx, epoch_dur, preimage) FROM stdin;
\.


--
-- Data for Name: epoch_reports; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.epoch_reports (epoch_end, epoch_dur, match_volume, quote_volume, book_buys, book_buys_5, book_buys_25, book_sells, book_sells_5, book_sells_25, high_rate, low_rate, start_rate, end_rate) FROM stdin;
\.


--
-- Data for Name: epochs; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.epochs (epoch_idx, epoch_dur, match_time, csum, seed, revealed, missed) FROM stdin;
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.matches (matchid, active, takersell, takerorder, takeraccount, takeraddress, makerorder, makeraccount, makeraddress, epochidx, epochdur, quantity, rate, baserate, quoterate, status, forgiven, sigmatchackmaker, sigmatchacktaker, acontractcoinid, acontract, acontracttime, bsigackofacontract, bcontractcoinid, bcontract, bcontracttime, asigackofbcontract, aredeemcoinid, aredeemsecret, aredeemtime, bsigackofaredeem, bredeemcoinid, bredeemtime) FROM stdin;
\.


--
-- Data for Name: orders_active; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.orders_active (oid, type, sell, account_id, address, client_time, server_time, commit, coins, quantity, rate, force, status, filled, epoch_idx, epoch_dur, preimage, complete_time) FROM stdin;
\.


--
-- Data for Name: orders_archived; Type: TABLE DATA; Schema: dcr_btc; Owner: dcrdex
--

COPY dcr_btc.orders_archived (oid, type, sell, account_id, address, client_time, server_time, commit, coins, quantity, rate, force, status, filled, epoch_idx, epoch_dur, preimage, complete_time) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: dcrdex
--

COPY public.accounts (account_id, pubkey, fee_address, fee_coin, broken_rule) FROM stdin;
\.


--
-- Data for Name: fee_keys; Type: TABLE DATA; Schema: public; Owner: dcrdex
--

COPY public.fee_keys (key_hash, child) FROM stdin;
\\x5432f70130b2f6cc7e1737758732039177909a29	0
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: public; Owner: dcrdex
--

COPY public.markets (name, base, quote, lot_size) FROM stdin;
btc_ltc	0	2	10000000000
dcr_btc	42	0	10000000000
\.


--
-- Name: cancels_active cancels_active_commit_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.cancels_active
    ADD CONSTRAINT cancels_active_commit_key UNIQUE (commit);


--
-- Name: cancels_active cancels_active_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.cancels_active
    ADD CONSTRAINT cancels_active_pkey PRIMARY KEY (oid);


--
-- Name: cancels_active cancels_active_preimage_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.cancels_active
    ADD CONSTRAINT cancels_active_preimage_key UNIQUE (preimage);


--
-- Name: cancels_archived cancels_archived_commit_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.cancels_archived
    ADD CONSTRAINT cancels_archived_commit_key UNIQUE (commit);


--
-- Name: cancels_archived cancels_archived_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.cancels_archived
    ADD CONSTRAINT cancels_archived_pkey PRIMARY KEY (oid);


--
-- Name: cancels_archived cancels_archived_preimage_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.cancels_archived
    ADD CONSTRAINT cancels_archived_preimage_key UNIQUE (preimage);


--
-- Name: epoch_reports epoch_reports_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.epoch_reports
    ADD CONSTRAINT epoch_reports_pkey PRIMARY KEY (epoch_end);


--
-- Name: epochs epochs_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.epochs
    ADD CONSTRAINT epochs_pkey PRIMARY KEY (epoch_idx, epoch_dur);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (matchid);


--
-- Name: orders_active orders_active_commit_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.orders_active
    ADD CONSTRAINT orders_active_commit_key UNIQUE (commit);


--
-- Name: orders_active orders_active_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.orders_active
    ADD CONSTRAINT orders_active_pkey PRIMARY KEY (oid);


--
-- Name: orders_active orders_active_preimage_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.orders_active
    ADD CONSTRAINT orders_active_preimage_key UNIQUE (preimage);


--
-- Name: orders_archived orders_archived_commit_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.orders_archived
    ADD CONSTRAINT orders_archived_commit_key UNIQUE (commit);


--
-- Name: orders_archived orders_archived_pkey; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.orders_archived
    ADD CONSTRAINT orders_archived_pkey PRIMARY KEY (oid);


--
-- Name: orders_archived orders_archived_preimage_key; Type: CONSTRAINT; Schema: btc_ltc; Owner: dcrdex
--

ALTER TABLE ONLY btc_ltc.orders_archived
    ADD CONSTRAINT orders_archived_preimage_key UNIQUE (preimage);


--
-- Name: cancels_active cancels_active_commit_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.cancels_active
    ADD CONSTRAINT cancels_active_commit_key UNIQUE (commit);


--
-- Name: cancels_active cancels_active_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.cancels_active
    ADD CONSTRAINT cancels_active_pkey PRIMARY KEY (oid);


--
-- Name: cancels_active cancels_active_preimage_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.cancels_active
    ADD CONSTRAINT cancels_active_preimage_key UNIQUE (preimage);


--
-- Name: cancels_archived cancels_archived_commit_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.cancels_archived
    ADD CONSTRAINT cancels_archived_commit_key UNIQUE (commit);


--
-- Name: cancels_archived cancels_archived_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.cancels_archived
    ADD CONSTRAINT cancels_archived_pkey PRIMARY KEY (oid);


--
-- Name: cancels_archived cancels_archived_preimage_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.cancels_archived
    ADD CONSTRAINT cancels_archived_preimage_key UNIQUE (preimage);


--
-- Name: epoch_reports epoch_reports_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.epoch_reports
    ADD CONSTRAINT epoch_reports_pkey PRIMARY KEY (epoch_end);


--
-- Name: epochs epochs_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.epochs
    ADD CONSTRAINT epochs_pkey PRIMARY KEY (epoch_idx, epoch_dur);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (matchid);


--
-- Name: orders_active orders_active_commit_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.orders_active
    ADD CONSTRAINT orders_active_commit_key UNIQUE (commit);


--
-- Name: orders_active orders_active_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.orders_active
    ADD CONSTRAINT orders_active_pkey PRIMARY KEY (oid);


--
-- Name: orders_active orders_active_preimage_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.orders_active
    ADD CONSTRAINT orders_active_preimage_key UNIQUE (preimage);


--
-- Name: orders_archived orders_archived_commit_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.orders_archived
    ADD CONSTRAINT orders_archived_commit_key UNIQUE (commit);


--
-- Name: orders_archived orders_archived_pkey; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.orders_archived
    ADD CONSTRAINT orders_archived_pkey PRIMARY KEY (oid);


--
-- Name: orders_archived orders_archived_preimage_key; Type: CONSTRAINT; Schema: dcr_btc; Owner: dcrdex
--

ALTER TABLE ONLY dcr_btc.orders_archived
    ADD CONSTRAINT orders_archived_preimage_key UNIQUE (preimage);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: dcrdex
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: fee_keys fee_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: dcrdex
--

ALTER TABLE ONLY public.fee_keys
    ADD CONSTRAINT fee_keys_pkey PRIMARY KEY (key_hash);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: public; Owner: dcrdex
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (name);


--
-- PostgreSQL database dump complete
--

